import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        //  Tworzymy listę dynamiczną (ArrayList), która będzie przechowywać obiekty klasy Person
        List<Person> people = new ArrayList<>();

        // Dodajemy nowe osoby do listy w losowej kolejności wiekowej
        people.add(new Person("Cezary", "Bąk", LocalDate.of(1990, 12, 12)));
        people.add(new Person("Ola", "Wis", LocalDate.of(2000, 1, 13)));
        people.add(new Person("Marlena", "Maron", LocalDate.of(2005, 9, 14)));

        // Wywołujemy sortowanie. Dzięki 'implements Comparable' w klasie Person,
        // Java wie, że ma sortować według daty urodzenia (this.dataUrodzin.compareTo)->to mamy w Pearson .
        Collections.sort(people);
        //Collections.reverse(people); // Odwraca Najmlodszy najstaarszy

        System.out.println("Lista osób posortowana od najstarszej do najmłodszej:");

        // Przechodzimy pętlą for-each przez posortowaną listę i wypisujemy dane
        for (Person person : people) {
            // Łączymy dane za pomocą operatora '+', bo println przyjmuje jeden ciąg znaków
            System.out.println(person.getImie() + " - " + person.getDataUrodzin());
        }

        // Opcjonalny test adopcji (żeby sprawdzić Twoją metodę logiczną)
        Person cezary = people.get(0); // Najstarszy (Cezary)
        Person marlena = people.get(2); // Najmłodsza (Marlena)

        cezary.adopt(marlena);
        System.out.println("\nNajmłodsze dziecko Cezarego: " + cezary.getYoungChild().getImie());
    }
}
import java.time.LocalDate;
import java.util.*;

public class Person implements Comparable<Person>{   // java ma wbudowany interfejs deklarujemy go implements comparable<Person>,interfejs ma wbudowane gettery settery i konstruktor
    private String imie;
    private String nazwisko;
    private LocalDate dataUrodzin;

    public Person(String imie, String nazwisko, LocalDate dataUrodzin) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.dataUrodzin = dataUrodzin;
    }

    private Set<Person>zbiorDzieci=new HashSet<>();

    public boolean adopt(Person dziecko){   //boolen sam z siebie zwraca true jesli dodano obiekt a jesli nie false
        return  zbiorDzieci.add(dziecko);


    }
    public Person getYoungChild(){
        Person najmlodsze=null;  // Inicjalizujemy zmienną pomocniczą; domyślnie null (jeśli nie będzie dzieci)

        for (Person person : zbiorDzieci) {  //przechodizmy petla po zbiorze Dzieci xd

            // Sprawdzamy: jeśli to pierwsze dziecko (najmlodsze jest jeszcze null)
            // LUB jeśli data urodzenia obecnego dziecka jest późniejsza (isAfter) niż dotychczasowego "lidera"
            if(najmlodsze==null || person.compareTo(najmlodsze)>0){  //isAfter() (odpowiednik >), isBefore() (odpowiednik <)

                najmlodsze=person; //Mamy naajmlodsze dziecko tu zapisane
            }
        }
        // Jeśli warunek spełniony, obecne dziecko staje się nowym najmłodszym
        return najmlodsze;
    }

    public List<Person>children(){
    List<Person> listaDzieci=new ArrayList<>(zbiorDzieci); // Przenoszeniue danych ze zbioru do listy

        //2. Sortujemy (korzysta z Twojego Comparable)
        Collections.sort(listaDzieci);

        //Zwracamy gotową, posortowaną listę
        return listaDzieci;

        }



    @Override
    public String toString() {
        return "Person{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", dataUrodzin=" + dataUrodzin +
                ", ZbiorDzieci=" + zbiorDzieci +
                '}';
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public LocalDate getDataUrodzin() {
        return dataUrodzin;
    }

    public Set<Person> getChildren() {
        return zbiorDzieci;
    }


    @Override
    public int compareTo(Person other) {

        //"Porównaj moją datę urodzenia z datą urodzenia tej drugiej osoby i zwróć wynik w formie liczby".
        return this.dataUrodzin.compareTo(other.dataUrodzin);
    }
}

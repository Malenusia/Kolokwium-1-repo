import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class DeathCauseStatisticlist {
    List<DeathCauseStatistic> lista = new ArrayList<>();

    public void repopulate(String path) throws FileNotFoundException {

        try {
            Scanner scanner = new Scanner(new File(path));
            scanner.nextLine();
            scanner.nextLine();
            lista.clear();
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine(); //wczytuje nastepan linie
                lista.add(DeathCauseStatistic.FromCsvLine(line));

            }
        } catch (FileNotFoundException e) {
            System.out.println("bład");
            throw new RuntimeException(e);
        }

    }

    public List<DeathCauseStatistic> mostDeadlyDiseases(int wiek, int n) {
        if (n >= lista.size()) {
            throw new RuntimeException("Za duza liczba");
        } else {
            return lista.stream().sorted((a,b)->Integer.compare(b.getAge(wiek).deathCount,a.getAge(wiek).deathCount)).limit(n).collect(Collectors.toList()); //sortownie malejace
        }


}
    public List<DeathCauseStatistic> getLista() {
        return lista;
    }

    @Override
    public String toString() {
        return "DeathCauseStatisticlist{" +
                "lista=" + lista +
                '}';
    }
}

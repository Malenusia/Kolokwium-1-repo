import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class ICDCodeTabularOptimizedForMemory implements ICDCodeTabular{

    public String getDescription(String code) {
        try{
        Scanner scanner=new Scanner(new File("src/icd10.txt"));
        for(int i=0;i<88;++i){
            scanner.nextLine();
        }


        while (scanner.hasNextLine()){
            String linie=scanner.nextLine().trim();
            if(linie.startsWith(code)){
                String[] part=linie.split(" ", 2); // dziele linie na 2 czesci ta liczba 2 mowi potenij na max 2 czesci
                return part[1]; //to jest oppis choroby pod tym indexem
            }

    }
        throw new IndexOutOfBoundsException("Nie ma takiej choroby ");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}




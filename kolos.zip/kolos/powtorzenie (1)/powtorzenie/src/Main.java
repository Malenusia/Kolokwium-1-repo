import java.io.FileNotFoundException;
import java.util.List;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        // 1. Test pojedynczej linii (to co już masz)
        DeathCauseStatistic deathCauseStatistic = DeathCauseStatistic.FromCsvLine("A04.7          ,758,-,-,-,-,-,1,-,1,3,5,9,12,30,58,64,94,161,192,95,33");
        System.out.println(deathCauseStatistic);

        ICDCodeTabularOptimizedForMemory manager2=new ICDCodeTabularOptimizedForMemory();
            String opis=manager2.getDescription("A02.9");
        DeathCauseStatisticlist manager = new DeathCauseStatisticlist();

            manager.repopulate("src/zgony.csv");

            System.out.println("Wczytano obiektów: " + manager.toString());
            System.out.println(manager.getLista());

        System.out.println("Choroby ");
        List<DeathCauseStatistic> choroby=manager.mostDeadlyDiseases(15, 4);
        System.out.println(choroby);

        System.out.println("Opis choroby");
        System.out.println(opis);

    }
}
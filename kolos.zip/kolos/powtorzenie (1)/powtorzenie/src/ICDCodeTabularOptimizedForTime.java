import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ICDCodeTabularOptimizedForTime implements ICDCodeTabular {
private Map<String, String>mapa=new HashMap<>(); //Klucz czyli choroba wartosc czyli opis

    public ICDCodeTabularOptimizedForTime(Map<String, String> mapa) {
        this.mapa = mapa;
    }
  public ICDCodeTabularOptimizedForTime(String path){
        try{
            Scanner scanner=new Scanner(new File("src/icd10.txt"));
            for(int i=0;i<88;++i){
                if(scanner.hasNextLine()) scanner.nextLine();
            }
            while(scanner.hasNextLine()){
                String line=scanner.nextLine();
                String [] parts=line.trim().split(" ", 2);

                if(parts.length>=2){
                    String kod=parts[0].trim();
                    String opis=parts[1].trim();


                    mapa.put(kod,opis);
                }


            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
  }
    @Override
    public String getDescription(String code) {
        return "";
    }
}

public class Motocykl extends Pojazd{

    public Motocykl(String marka) {
        super(marka);
    }

    @Override
    public void uruchomSilnik() {
        System.out.println("Wrrrrrr");
    }
}

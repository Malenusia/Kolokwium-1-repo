import java.util.logging.SocketHandler;

public class Main{
    public static void main(String [] args) {

        Pojazd auto = new Samochod("Opel");
        Pojazd motor = new Motocykl("Yahama");
        Tesla marka=new Tesla("Model S");

      auto.wyswietlMarke();
      auto.uruchomSilnik();

        System.out.println("--------------------------------------------");
      motor.wyswietlMarke();
      motor.uruchomSilnik();
        System.out.println("--------------------------------------------");
      marka.wyswietlMarke();
      marka.ladujbaterie();
    }
}

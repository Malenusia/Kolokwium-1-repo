public class Tesla extends Samochod implements elektryczny{

    public Tesla(String marka) {
        super(marka);
    }

    @Override
    public void ladujbaterie() {
        System.out.println("ladowanie supercharem lol gowno");
    }
}

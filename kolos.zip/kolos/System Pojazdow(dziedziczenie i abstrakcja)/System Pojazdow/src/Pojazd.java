public abstract class Pojazd {
    String marka;

    public Pojazd(String marka) {
        this.marka = marka;
    }
    public abstract void uruchomSilnik();

    public void wyswietlMarke(){
        System.out.println("Pojazd marki: "  + marka);

    }

    public String getMarka() {
        return marka;
    }
}

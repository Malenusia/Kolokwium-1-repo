public interface elektryczny {
    void ladujbaterie();
}

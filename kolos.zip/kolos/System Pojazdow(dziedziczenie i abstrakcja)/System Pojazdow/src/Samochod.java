public class Samochod extends Pojazd {

    public Samochod(String marka) {
        super(marka);

    }

    @Override
    public void uruchomSilnik() {
        System.out.println("brum brum");
    }
}
